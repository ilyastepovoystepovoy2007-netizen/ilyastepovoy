# config.py

# Выбор СУБД: 'sqlite', 'postgresql', 'mysql'
DB_TYPE = 'sqlite'

# Для SQLite
SQLITE_DB = 'users.db'

# Для PostgreSQL (установите psycopg2: pip install psycopg2-binary)
POSTGRESQL_CONFIG = {
    'host': 'localhost',
    'database': 'auth_db',
    'user': 'postgres',
    'password': 'password',
    'port': 5432
}

# Для MySQL (установите mysql-connector-python: pip install mysql-connector-python)
MYSQL_CONFIG = {
    'host': 'localhost',
    'database': 'auth_db',
    'user': 'root',
    'password': 'password',
    'port': 3306
}