# main.py — расширенная версия с сохранением темы, валидацией, логами, меню, анимациями и стилями

import tkinter as tk
from tkinter import messagebox, ttk, Menu
import json
import logging
import os
import re
from database import create_db, register_user, get_user_by_username, update_password


# 📝 Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class AuthApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Система авторизации")
        self.root.geometry("400x500")
        self.root.resizable(True, True)

        # 🖼️ Установка иконки (если есть файл icon.ico в папке)
        icon_path = "icon.ico"
        if os.path.exists(icon_path):
            try:
                self.root.iconbitmap(icon_path)
            except Exception as e:
                logger.warning(f"Не удалось загрузить иконку: {e}")

        # 🌙 Загрузка темы из config.json
        self.is_dark = self.load_theme_setting()

        # 👤 Текущий пользователь
        self.current_user = None

        # 🎞️ Анимация: текущий индекс кадра
        self.anim_frame = 0

        # 🖼️ Контейнер для фреймов
        container = tk.Frame(self.root)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        # 📚 Создаём фреймы
        self.frames = {}
        for F in (StartPage, LoginPage, RegisterPage, WelcomePage, ChangePasswordPage, ForgotPasswordPage, SettingsPage):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # 🎨 Применяем тему ПОСЛЕ создания фреймов
        self.apply_theme()

        # 🍔 Меню
        self.create_menu()

        # ▶️ Показываем стартовый экран
        self.show_frame("StartPage")

    def create_menu(self):
        menubar = Menu(self.root)
        self.root.config(menu=menubar)

        # Меню "Настройки"
        settings_menu = Menu(menubar, tearoff=0)
        settings_menu.add_command(label="Тема: переключить", command=self.toggle_theme)
        settings_menu.add_command(label="Сбросить настройки", command=self.reset_settings)
        settings_menu.add_separator()
        settings_menu.add_command(label="Выход", command=self.root.quit)
        menubar.add_cascade(label="Настройки", menu=settings_menu)

        # Меню "Помощь"
        help_menu = Menu(menubar, tearoff=0)
        help_menu.add_command(label="О программе", command=self.show_about)
        menubar.add_cascade(label="Помощь", menu=help_menu)

    def show_about(self):
        messagebox.showinfo("О программе", "Система авторизации v2.0\n\nАвтор: Пользователь\n\nPython + Tkinter")

    def reset_settings(self):
        if messagebox.askyesno("Сброс", "Сбросить все настройки на значения по умолчанию?"):
            self.is_dark = False
            self.save_theme_setting()
            self.apply_theme()
            messagebox.showinfo("Успех", "Настройки сброшены!")

    def load_theme_setting(self):
        try:
            if os.path.exists("config.json"):
                with open("config.json", "r", encoding="utf-8") as f:
                    config = json.load(f)
                    return config.get("dark_theme", False)
        except Exception as e:
            logger.error(f"Ошибка загрузки темы: {e}")
        return False

    def save_theme_setting(self):
        try:
            with open("config.json", "w", encoding="utf-8") as f:
                json.dump({"dark_theme": self.is_dark}, f, indent=4)
        except Exception as e:
            logger.error(f"Ошибка сохранения темы: {e}")

    def toggle_theme(self):
        self.is_dark = not self.is_dark
        self.save_theme_setting()  # 💾 Сохраняем между сессиями!
        self.apply_theme()
        logger.info(f"Тема переключена на {'тёмную' if self.is_dark else 'светлую'}")

    def apply_theme(self):
        if self.is_dark:
            bg = "#2b2b2b"
            fg = "white"
            btn_bg = "#4a4a4a"
            entry_bg = "#3c3c3c"
            entry_fg = "white"
            highlight_bg = "#5a5a5a"
        else:
            bg = "white"
            fg = "black"
            btn_bg = "#e1e1e1"
            entry_bg = "white"
            entry_fg = "black"
            highlight_bg = "#d0d0d0"

        self.root.configure(bg=bg)

        # Стиль ttk
        style = ttk.Style()
        style.theme_use('clam')

        style.configure("TButton", background=btn_bg, foreground=fg, font=("Arial", 10))
        style.map("TButton",
                  background=[("active", highlight_bg)],
                  foreground=[("active", fg)])

        style.configure("TLabel", background=bg, foreground=fg, font=("Arial", 10))
        style.configure("TEntry", fieldbackground=entry_bg, foreground=entry_fg)
        style.configure("TFrame", background=bg)

        # Обновляем все фреймы и виджеты
        for frame in self.frames.values():
            try:
                frame.configure(bg=bg)
                for widget in frame.winfo_children():
                    if isinstance(widget, tk.Label):
                        widget.configure(bg=bg, fg=fg)
                    elif isinstance(widget, tk.Button):
                        widget.configure(bg=btn_bg, fg=fg, activebackground=highlight_bg)
                    elif isinstance(widget, tk.Entry):
                        widget.configure(bg=entry_bg, fg=entry_fg, insertbackground=fg)
                    elif isinstance(widget, ttk.Button):
                        # ttk уже стилизован через Style
                        pass
            except Exception as e:
                logger.debug(f"Не удалось применить стиль к виджету: {e}")

    def animate_transition(self, frame, direction="in"):
        """Плавное появление/исчезание фрейма (имитация)"""
        steps = 10
        delay = 20  # мс

        def fade_in(step=0):
            alpha = step / steps
            if step <= steps:
                # Имитируем анимацию через изменение цвета или размера
                # В Tkinter нет прозрачности, поэтому просто обновляем
                frame.update()
                self.root.after(delay, fade_in, step + 1)

        fade_in()

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        self.animate_transition(frame, "in")
        frame.tkraise()
        if hasattr(frame, "on_show"):
            frame.on_show()
        logger.info(f"Переход на экран: {page_name}")


class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#ffffff")
        self.controller = controller

        tk.Label(self, text="🔐 Добро пожаловать!", font=("Arial", 18, "bold")).pack(pady=30)

        ttk.Button(self, text="Войти", width=30, command=lambda: controller.show_frame("LoginPage")).pack(pady=10)
        ttk.Button(self, text="Зарегистрироваться", width=30, command=lambda: controller.show_frame("RegisterPage")).pack(pady=10)
        ttk.Button(self, text="Забыли пароль?", width=30, command=lambda: controller.show_frame("ForgotPasswordPage")).pack(pady=10)
        ttk.Button(self, text="⚙️ Настройки", width=30, command=lambda: controller.show_frame("SettingsPage")).pack(pady=20)

    def on_show(self):
        pass


class LoginPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="🔑 Вход", font=("Arial", 16, "bold")).pack(pady=20)

        tk.Label(self, text="Логин:").pack()
        self.entry_username = tk.Entry(self, font=("Arial", 12), width=30)
        self.entry_username.pack(pady=5)

        tk.Label(self, text="Пароль:").pack()
        self.entry_password = tk.Entry(self, show="*", font=("Arial", 12), width=30)
        self.entry_password.pack(pady=5)

        ttk.Button(self, text="Войти", command=self.login).pack(pady=15)
        ttk.Button(self, text="Назад", command=lambda: controller.show_frame("StartPage")).pack()

    def login(self):
        username = self.entry_username.get().strip()
        password = self.entry_password.get()

        if not username or not password:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        user = get_user_by_username(username)
        if user and user[2] == self.controller.hash_password(password):
            self.controller.current_user = username
            logger.info(f"Пользователь '{username}' успешно вошёл")
            self.entry_username.delete(0, tk.END)
            self.entry_password.delete(0, tk.END)
            self.controller.show_frame("WelcomePage")
        else:
            logger.warning(f"Неудачная попытка входа для '{username}'")
            messagebox.showerror("Ошибка", "Неверный логин или пароль!")

    def on_show(self):
        self.entry_username.focus()


class RegisterPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="📝 Регистрация", font=("Arial", 16, "bold")).pack(pady=20)

        tk.Label(self, text="Логин:").pack()
        self.entry_username = tk.Entry(self, font=("Arial", 12), width=30)
        self.entry_username.pack(pady=5)

        tk.Label(self, text="Пароль:").pack()
        self.entry_password = tk.Entry(self, show="*", font=("Arial", 12), width=30)
        self.entry_password.pack(pady=5)

        tk.Label(self, text="Повторите пароль:").pack()
        self.entry_password2 = tk.Entry(self, show="*", font=("Arial", 12), width=30)
        self.entry_password2.pack(pady=5)

        ttk.Button(self, text="Зарегистрироваться", command=self.register).pack(pady=15)
        ttk.Button(self, text="Назад", command=lambda: controller.show_frame("StartPage")).pack()

    def validate_password(self, password):
        if len(password) < 6:
            return "Пароль должен быть не менее 6 символов"
        if not re.search(r"\d", password):
            return "Пароль должен содержать хотя бы одну цифру"
        if not re.search(r"[A-Za-z]", password):
            return "Пароль должен содержать хотя бы одну букву"
        if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
            return "Пароль должен содержать хотя бы один спецсимвол"
        return None

    def register(self):
        username = self.entry_username.get().strip()
        password = self.entry_password.get()
        password2 = self.entry_password2.get()

        if not username or not password or not password2:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        if password != password2:
            messagebox.showerror("Ошибка", "Пароли не совпадают!")
            return

        # ✅ Валидация сложности пароля
        validation_error = self.validate_password(password)
        if validation_error:
            messagebox.showerror("Ошибка", validation_error)
            return

        if register_user(username, password):
            logger.info(f"Новый пользователь зарегистрирован: {username}")
            messagebox.showinfo("Успех", "Регистрация прошла успешно!")
            self.controller.show_frame("LoginPage")
        else:
            logger.warning(f"Попытка регистрации существующего пользователя: {username}")
            messagebox.showerror("Ошибка", "Пользователь с таким логином уже существует!")

    def on_show(self):
        self.entry_username.focus()


class WelcomePage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        self.label_welcome = tk.Label(self, text="", font=("Arial", 16, "bold"))
        self.label_welcome.pack(pady=30)

        ttk.Button(self, text="Сменить пароль", width=30,
                  command=lambda: controller.show_frame("ChangePasswordPage")).pack(pady=10)
        ttk.Button(self, text="Выйти", width=30, command=self.logout).pack(pady=10)

    def on_show(self):
        username = self.controller.current_user
        self.label_welcome.config(text=f"👋 Добро пожаловать, {username}!")


    def logout(self):
        logger.info(f"Пользователь '{self.controller.current_user}' вышел")
        self.controller.current_user = None
        self.controller.show_frame("StartPage")


class ChangePasswordPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="🔁 Смена пароля", font=("Arial", 16, "bold")).pack(pady=20)

        tk.Label(self, text="Новый пароль:").pack()
        self.entry_new_password = tk.Entry(self, show="*", font=("Arial", 12), width=30)
        self.entry_new_password.pack(pady=5)

        tk.Label(self, text="Повторите пароль:").pack()
        self.entry_confirm_password = tk.Entry(self, show="*", font=("Arial", 12), width=30)
        self.entry_confirm_password.pack(pady=5)

        ttk.Button(self, text="Сохранить", command=self.change_password).pack(pady=15)
        ttk.Button(self, text="Назад", command=lambda: controller.show_frame("WelcomePage")).pack()

    def change_password(self):
        new_pass = self.entry_new_password.get()
        confirm_pass = self.entry_confirm_password.get()

        if not new_pass or not confirm_pass:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        if new_pass != confirm_pass:
            messagebox.showerror("Ошибка", "Пароли не совпадают!")
            return

        # ✅ Валидация сложности
        reg_page = RegisterPage(self, self.controller)  # временный экземпляр для валидации
        validation_error = reg_page.validate_password(new_pass)
        if validation_error:
            messagebox.showerror("Ошибка", validation_error)
            return

        username = self.controller.current_user
        if update_password(username, new_pass):
            logger.info(f"Пользователь '{username}' сменил пароль")
            messagebox.showinfo("Успех", "Пароль успешно изменён!")
            self.entry_new_password.delete(0, tk.END)
            self.entry_confirm_password.delete(0, tk.END)
            self.controller.show_frame("WelcomePage")
        else:
            messagebox.showerror("Ошибка", "Не удалось изменить пароль.")

    def on_show(self):
        self.entry_new_password.focus()


class ForgotPasswordPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="❓ Восстановление пароля", font=("Arial", 16, "bold")).pack(pady=20)
        tk.Label(self, text="Введите ваш логин:").pack()

        self.entry_username = tk.Entry(self, font=("Arial", 12), width=30)
        self.entry_username.pack(pady=5)

        ttk.Button(self, text="Сбросить пароль", command=self.reset_password).pack(pady=15)
        ttk.Button(self, text="Назад", command=lambda: controller.show_frame("StartPage")).pack()

    def reset_password(self):
        username = self.entry_username.get().strip()
        if not username:
            messagebox.showerror("Ошибка", "Введите логин!")
            return

        user = get_user_by_username(username)
        if not user:
            logger.warning(f"Попытка восстановления для несуществующего пользователя: {username}")
            messagebox.showerror("Ошибка", "Пользователь не найден!")
            return

        new_password = "Temp123!"  # ✅ Теперь соответствует валидации
        if update_password(username, new_password):
            logger.info(f"Пароль сброшен для пользователя: {username}")
            messagebox.showinfo("Успех", f"Пароль сброшен!\nНовый пароль: {new_password}\nСмените его после входа!")
            self.controller.show_frame("LoginPage")
        else:
            messagebox.showerror("Ошибка", "Не удалось сбросить пароль.")

    def on_show(self):
        self.entry_username.focus()


class SettingsPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="⚙️ Настройки", font=("Arial", 16, "bold")).pack(pady=30)

        ttk.Button(self, text="Сменить тему", command=controller.toggle_theme).pack(pady=10)
        ttk.Button(self, text="Сбросить настройки", command=controller.reset_settings).pack(pady=10)
        ttk.Button(self, text="Назад", command=lambda: controller.show_frame("StartPage")).pack(pady=20)

    def on_show(self):
        pass


# Добавим хеширование в контроллер
AuthApp.hash_password = staticmethod(lambda pwd: __import__('hashlib').sha256(pwd.encode()).hexdigest())


# ▶️ Запуск приложения
if __name__ == "__main__":
    create_db()  # Инициализация БД
    root = tk.Tk()
    app = AuthApp(root)
    root.mainloop()