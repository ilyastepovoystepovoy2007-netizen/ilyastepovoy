# database.py

import sqlite3
import hashlib
import psycopg2
import mysql.connector
from config import DB_TYPE, SQLITE_DB, POSTGRESQL_CONFIG, MYSQL_CONFIG


def get_connection():
    if DB_TYPE == 'sqlite':
        conn = sqlite3.connect(SQLITE_DB)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
    elif DB_TYPE == 'postgresql':
        return psycopg2.connect(**POSTGRESQL_CONFIG)
    elif DB_TYPE == 'mysql':
        return mysql.connector.connect(**MYSQL_CONFIG)
    else:
        raise ValueError("Unsupported DB_TYPE in config.py")


def create_db():
    conn = get_connection()
    cursor = conn.cursor()

    if DB_TYPE == 'sqlite':
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
    elif DB_TYPE == 'postgresql':
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
    elif DB_TYPE == 'mysql':
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')

    conn.commit()
    conn.close()


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def register_user(username, password):
    hashed = hash_password(password)
    conn = get_connection()
    cursor = conn.cursor()
    try:
        if DB_TYPE == 'sqlite':
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed))
        else:
            cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed))
        conn.commit()
        return True
    except Exception as e:
        conn.rollback()
        print("Ошибка регистрации:", e)
        return False
    finally:
        conn.close()


def get_user_by_username(username):
    conn = get_connection()
    cursor = conn.cursor()
    if DB_TYPE == 'sqlite':
        cursor.execute("SELECT id, username, password FROM users WHERE username = ?", (username,))
    else:
        cursor.execute("SELECT id, username, password FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    conn.close()
    return user


def update_password(username, new_password):
    hashed = hash_password(new_password)
    conn = get_connection()
    cursor = conn.cursor()
    try:
        if DB_TYPE == 'sqlite':
            cursor.execute("UPDATE users SET password = ? WHERE username = ?", (hashed, username))
        else:
            cursor.execute("UPDATE users SET password = %s WHERE username = %s", (hashed, username))
        conn.commit()
        return cursor.rowcount > 0
    except Exception as e:
        conn.rollback()
        print("Ошибка смены пароля:", e)
        return False
    finally:
        conn.close()